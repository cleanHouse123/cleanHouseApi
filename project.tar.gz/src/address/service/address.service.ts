import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AddressResponseDto } from '../dto/address-response.dto';
import { AddressCache } from '../entities/address-cache.entity';
import { Location } from '../entities/location.entity';
import { CreateLocationDto, LocationDto } from '../dto/location.dto';
import { DaDataService } from './dadata.service';

@Injectable()
export class AddressService {
  constructor(
    @InjectRepository(AddressCache)
    private readonly addressCacheRepository: Repository<AddressCache>,
    @InjectRepository(Location)
    private readonly locationRepository: Repository<Location>,
    private readonly daDataService: DaDataService,
  ) {}

  async getLocations(): Promise<LocationDto[]> {
    const locations = await this.locationRepository
      .createQueryBuilder('location')
      .select([
        'location.id',
        'location.region',
        'location.area',
        'location.city',
        'location.settlement',
        'location.street',
        'location.created_at',
        'location.updated_at',
      ])
      .where(
        'location.region IS NOT NULL OR location.area IS NOT NULL OR location.city IS NOT NULL OR location.settlement IS NOT NULL OR location.street IS NOT NULL',
      )
      .getMany();

    return locations;
  }

  async createLocation(location: CreateLocationDto): Promise<LocationDto> {
    const newLocation = this.locationRepository.create(location);
    return this.locationRepository.save(newLocation);
  }

  async deleteLocation(id: string): Promise<void> {
    await this.locationRepository.delete(id);
  }

  async getCoordinatesByAddress(
    address: string,
  ): Promise<{ lat: number; lon: number } | null> {
    try {
      const addresses = await this.findAll(address);
      if (
        addresses.length > 0 &&
        addresses[0].geo_lat &&
        addresses[0].geo_lon
      ) {
        return {
          lat: parseFloat(addresses[0].geo_lat),
          lon: parseFloat(addresses[0].geo_lon),
        };
      }
      return null;
    } catch (error) {
      console.error('Ошибка получения координат:', error);
      return null;
    }
  }

  async findAll(query: string): Promise<AddressResponseDto[]> {
    if (!query || query.trim().length < 2) {
      let cacheEntry = await this.addressCacheRepository
        .createQueryBuilder('cache')
        .orderBy('cache.search_count', 'DESC')
        .addOrderBy('cache.last_searched_at', 'DESC')
        .limit(10)
        .getMany();
      return cacheEntry?.map((entry) => entry.cached_results).flat() || [];
    }

    const normalizedQuery = this.normalizeQuery(query);

    const cachedResults = await this.findInCache(normalizedQuery);
    if (cachedResults.length > 0) {
      await this.updateSearchStats(normalizedQuery);
      return cachedResults;
    }

    return await this.findInApiAndSaveToCache(query, normalizedQuery);
  }

  private normalizeQuery(query: string): string {
    return query.trim().toLowerCase();
  }

  private async findInApiAndSaveToCache(
    query: string,
    normalizedQuery: string,
  ): Promise<AddressResponseDto[]> {
    try {
      const apiResults = await this.daDataService.searchAddresses(query, false);

      if (apiResults.length > 0) {
        await this.saveToCache(normalizedQuery, apiResults);
      }

      return apiResults;
    } catch (error) {
      console.error('Ошибка при поиске в DaData API:', error);
      throw new Error('Не удалось получить адреса');
    }
  }

  private async findInCache(query: string): Promise<AddressResponseDto[]> {
    try {
      let cacheEntry = await this.addressCacheRepository.findOne({
        where: { query },
        order: { last_searched_at: 'DESC' },
      });

      if (!cacheEntry) {
        cacheEntry = await this.addressCacheRepository
          .createQueryBuilder('cache')
          .where('cache.query ILIKE :query', { query: `%${query}%` })
          .orderBy('cache.search_count', 'DESC')
          .addOrderBy('cache.last_searched_at', 'DESC')
          .limit(1)
          .getOne();
      }

      if (cacheEntry) {
        return cacheEntry.cached_results;
      }

      return [];
    } catch (error) {
      console.error('Ошибка при поиске в кэше:', error);
      return [];
    }
  }

  private async updateSearchStats(query: string): Promise<void> {
    try {
      await this.addressCacheRepository
        .createQueryBuilder()
        .update(AddressCache)
        .set({
          search_count: () => 'search_count + 1',
          last_searched_at: new Date(),
        })
        .where('query = :query', { query })
        .execute();
    } catch (error) {
      console.error('Ошибка при обновлении статистики поиска:', error);
    }
  }

  private async saveToCache(
    query: string,
    results: AddressResponseDto[],
  ): Promise<void> {
    try {
      const cityOrSettlement = results[0]?.city_or_settlement || null;

      const cacheEntry = this.addressCacheRepository.create({
        query,
        city_or_settlement: cityOrSettlement,
        cached_results: results,
        search_count: 1,
        last_searched_at: new Date(),
      });

      await this.addressCacheRepository.save(cacheEntry);
    } catch (error) {
      console.error('Ошибка при сохранении в кэш:', error);
    }
  }


  async cleanOldCache(daysOld: number = 30): Promise<{ deletedCount: number }> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysOld);

      const result = await this.addressCacheRepository
        .createQueryBuilder()
        .delete()
        .where('last_searched_at < :cutoffDate', { cutoffDate })
        .execute();

      console.log(`Очищено ${result.affected} устаревших записей кэша`);
      return { deletedCount: result.affected || 0 };
    } catch (error) {
      console.error('Ошибка при очистке старого кэша:', error);
      throw new Error('Не удалось очистить кэш');
    }
  }

  async isSupportableAddress(address: AddressResponseDto): Promise<boolean> {
    return this.daDataService.isSupportableAddressByDaData(address);
  }

  async limitCacheSize(
    maxRecords: number = 1000,
  ): Promise<{ deletedCount: number }> {
    try {
      const totalCount = await this.addressCacheRepository.count();

      if (totalCount <= maxRecords) {
        return { deletedCount: 0 };
      }

      const recordsToKeep = await this.addressCacheRepository
        .createQueryBuilder('cache')
        .select('cache.id')
        .orderBy('cache.search_count', 'DESC')
        .addOrderBy('cache.last_searched_at', 'DESC')
        .limit(maxRecords)
        .getMany();

      const idsToKeep = recordsToKeep.map((record) => record.id);

      const result = await this.addressCacheRepository
        .createQueryBuilder()
        .delete()
        .where('id NOT IN (:...ids)', { ids: idsToKeep })
        .execute();

      console.log(`Ограничен размер кэша: удалено ${result.affected} записей`);
      return { deletedCount: result.affected || 0 };
    } catch (error) {
      console.error('Ошибка при ограничении размера кэша:', error);
      throw new Error('Не удалось ограничить размер кэша');
    }
  }

  async clearAllCache(): Promise<{ deletedCount: number }> {
    try {
      const result = await this.addressCacheRepository
        .createQueryBuilder()
        .delete()
        .execute();

      console.log(`Полностью очищен кэш: удалено ${result.affected} записей`);
      return { deletedCount: result.affected || 0 };
    } catch (error) {
      console.error('Ошибка при полной очистке кэша:', error);
      throw new Error('Не удалось очистить кэш');
    }
  }

  async getCacheStats(): Promise<{
    total: number;
    mostSearched: Array<{
      query: string;
      search_count: number;
      last_searched_at: Date;
      city_or_settlement: string | null;
    }>;
    recentSearches: Array<{
      query: string;
      last_searched_at: Date;
      search_count: number;
    }>;
  }> {
    try {
      const total = await this.addressCacheRepository.count();

      const mostSearched = await this.addressCacheRepository
        .createQueryBuilder('cache')
        .select([
          'cache.query',
          'cache.search_count',
          'cache.last_searched_at',
          'cache.city_or_settlement',
        ])
        .orderBy('cache.search_count', 'DESC')
        .limit(10)
        .getMany();

      const recentSearches = await this.addressCacheRepository
        .createQueryBuilder('cache')
        .select(['cache.query', 'cache.last_searched_at', 'cache.search_count'])
        .orderBy('cache.last_searched_at', 'DESC')
        .limit(10)
        .getMany();

      return { total, mostSearched, recentSearches };
    } catch (error) {
      console.error('Ошибка при получении статистики кэша:', error);
      return { total: 0, mostSearched: [], recentSearches: [] };
    }
  }

  async performMaintenance(): Promise<{
    oldRecordsDeleted: number;
    excessRecordsDeleted: number;
    totalDeleted: number;
  }> {
    try {
      console.log('Начинаем обслуживание кэша...');

      const oldResult = await this.cleanOldCache(30);

      const excessResult = await this.limitCacheSize(1000);

      const totalDeleted = oldResult.deletedCount + excessResult.deletedCount;

      console.log(
        `Обслуживание кэша завершено. Удалено записей: ${totalDeleted}`,
      );

      return {
        oldRecordsDeleted: oldResult.deletedCount,
        excessRecordsDeleted: excessResult.deletedCount,
        totalDeleted,
      };
    } catch (error) {
      console.error('Ошибка при обслуживании кэша:', error);
      throw new Error('Не удалось выполнить обслуживание кэша');
    }
  }
}
