export const expiresAccessIn = '7m';
export const expiresRefreshIn = '15d';

export const DEFAULT_PAGE = 1;
export const DEFAULT_LIMIT = 10;
