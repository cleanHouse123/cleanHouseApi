export enum AdTokenType {
  ADS = 'ad',
  REFERRAL = 'referral',
}
