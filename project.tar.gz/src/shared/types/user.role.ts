export enum UserRole {
  ADMIN = 'admin',
  CUSTOMER = 'customer',
  CURRIER = 'currier',
}
