import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Injectable, Logger, ForbiddenException } from '@nestjs/common';
import { PaymentService } from '../services/payment.service';
import { SubscriptionService } from '../subscription.service';

@Injectable()
@WebSocketGateway({
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
    credentials: true,
  },
  namespace: '/subscription-payment',
})
export class PaymentGateway {
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger(PaymentGateway.name);
  private paymentCheckIntervals = new Map<string, NodeJS.Timeout>();

  constructor(
    private readonly paymentService: PaymentService,
    private readonly subscriptionService: SubscriptionService,
  ) {}

  // Обработка подключения клиента
  handleConnection(client: Socket) {
    this.logger.log(`Client connected: ${client.id}`);
  }

  // Обработка отключения клиента
  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`);
  }

  // Отправка уведомления о успешной оплате
  notifyPaymentSuccess(paymentId: string, subscriptionId: string) {
    const roomName = `payment_${paymentId}`;
    this.logger.log(
      `[SUBSCRIPTION PAYMENT SUCCESS] PaymentId: ${paymentId}, SubscriptionId: ${subscriptionId}, Room: ${roomName}`,
    );

    this.server.to(roomName).emit('payment_success', {
      paymentId,
      subscriptionId,
      message: 'Подписка успешно оформлена!',
      timestamp: new Date().toISOString(),
    });

    this.logger.log(
      `[SUBSCRIPTION PAYMENT SUCCESS] Event sent to room: ${roomName}`,
    );
  }

  // Отправка уведомления об ошибке оплаты
  notifyPaymentError(paymentId: string, subscriptionId: string, error: string) {
    const roomName = `payment_${paymentId}`;
    this.logger.error(
      `[SUBSCRIPTION PAYMENT ERROR] PaymentId: ${paymentId}, SubscriptionId: ${subscriptionId}, Error: ${error}, Room: ${roomName}`,
    );

    this.server.to(roomName).emit('payment_error', {
      paymentId,
      subscriptionId,
      error,
      timestamp: new Date().toISOString(),
    });

    this.logger.error(
      `[SUBSCRIPTION PAYMENT ERROR] Event sent to room: ${roomName}`,
    );
  }

  // Подключение клиента с проверкой прав доступа
  @SubscribeMessage('join_payment_room')
  async handleJoinRoom(
    @MessageBody() data: { userId: string; paymentId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      // Проверяем права доступа к платежу
      const payment = await this.paymentService.getPayment(
        data.paymentId,
        data.userId,
      );

      if (!payment) {
        this.logger.warn(
          `[SUBSCRIPTION JOIN ROOM] Payment ${data.paymentId} not found or access denied for user ${data.userId}`,
        );
        client.disconnect();
        return { error: 'Платеж не найден или нет прав доступа' };
      }

      const roomName = `payment_${data.paymentId}`;
      this.logger.log(
        `[SUBSCRIPTION JOIN ROOM] Client: ${client.id}, UserId: ${data.userId}, PaymentId: ${data.paymentId}, Room: ${roomName}`,
      );

      client.join(roomName);
      this.logger.log(
        `[SUBSCRIPTION JOIN ROOM] Client ${client.id} successfully joined room: ${roomName}`,
      );

      // Запускаем периодическую проверку статуса платежа
      this.logger.log(
        `[SUBSCRIPTION JOIN ROOM] Starting payment status check for PaymentId: ${data.paymentId}`,
      );
      this.startPaymentStatusCheck(data.paymentId, roomName, data.userId);

      return { message: 'Подключен к комнате оплаты', room: roomName };
    } catch (error) {
      this.logger.error(
        `[SUBSCRIPTION JOIN ROOM] Error joining room for PaymentId: ${data.paymentId}, UserId: ${data.userId}`,
        error,
      );
      client.disconnect();
      return { error: 'Ошибка подключения к комнате оплаты' };
    }
  }

  // Отключение клиента с проверкой прав доступа
  @SubscribeMessage('leave_payment_room')
  async handleLeaveRoom(
    @MessageBody() data: { userId: string; paymentId: string },
    @ConnectedSocket() client: Socket,
  ) {
    try {
      // Проверяем права доступа к платежу
      const payment = await this.paymentService.getPayment(
        data.paymentId,
        data.userId,
      );

      if (!payment) {
        this.logger.warn(
          `[SUBSCRIPTION LEAVE ROOM] Payment ${data.paymentId} not found or access denied for user ${data.userId}`,
        );
        return { error: 'Платеж не найден или нет прав доступа' };
      }

      const roomName = `payment_${data.paymentId}`;
      this.logger.log(
        `[SUBSCRIPTION LEAVE ROOM] Client: ${client.id}, UserId: ${data.userId}, PaymentId: ${data.paymentId}, Room: ${roomName}`,
      );

      client.leave(roomName);
      this.logger.log(
        `[SUBSCRIPTION LEAVE ROOM] Client ${client.id} successfully left room: ${roomName}`,
      );

      // Останавливаем проверку статуса платежа
      this.logger.log(
        `[SUBSCRIPTION LEAVE ROOM] Stopping payment status check for PaymentId: ${data.paymentId}`,
      );
      this.stopPaymentStatusCheck(data.paymentId);

      return { message: 'Отключен от комнаты оплаты' };
    } catch (error) {
      this.logger.error(
        `[SUBSCRIPTION LEAVE ROOM] Error leaving room for PaymentId: ${data.paymentId}, UserId: ${data.userId}`,
        error,
      );
      return { error: 'Ошибка отключения от комнаты оплаты' };
    }
  }

  // Запуск периодической проверки статуса платежа
  private startPaymentStatusCheck(
    paymentId: string,
    roomName: string,
    userId?: string,
  ) {
    // Останавливаем предыдущую проверку, если она была
    this.stopPaymentStatusCheck(paymentId);
    this.logger.log(
      `[SUBSCRIPTION STATUS CHECK] Starting periodic check for PaymentId: ${paymentId}, Room: ${roomName}`,
    );

    const interval = setInterval(async () => {
      try {
        const payment = await this.paymentService.getPayment(paymentId, userId);

        if (!payment) {
          this.logger.warn(
            `[SUBSCRIPTION STATUS CHECK] Payment ${paymentId} not found, stopping check`,
          );
          this.stopPaymentStatusCheck(paymentId);
          return;
        }

        this.logger.log(
          `[SUBSCRIPTION STATUS CHECK] PaymentId: ${paymentId}, Status: ${payment.status}, Room: ${roomName}`,
        );

        // Отправляем текущий статус платежа
        this.server.to(roomName).emit('payment_status_update', {
          paymentId,
          status: payment.status,
          timestamp: new Date().toISOString(),
        });
        this.logger.log(
          `[SUBSCRIPTION STATUS CHECK] Status update sent to room: ${roomName}`,
        );

        // Если платеж завершен (успешно или с ошибкой), останавливаем проверку
        if (payment.status === 'success' || payment.status === 'failed') {
          this.logger.log(
            `[SUBSCRIPTION STATUS CHECK] Payment ${paymentId} completed with status: ${payment.status}, stopping check`,
          );
          this.stopPaymentStatusCheck(paymentId);

          // Отправляем финальное уведомление
          if (payment.status === 'success') {
            this.logger.log(
              `[SUBSCRIPTION STATUS CHECK] Sending success notification for PaymentId: ${paymentId}`,
            );
            this.server.to(roomName).emit('payment_success', {
              paymentId,
              subscriptionId: payment.subscriptionId,
              message: 'Оплата прошла успешно! Подписка активирована.',
              timestamp: new Date().toISOString(),
            });
          } else {
            this.logger.log(
              `[SUBSCRIPTION STATUS CHECK] Sending error notification for PaymentId: ${paymentId}`,
            );
            this.server.to(roomName).emit('payment_error', {
              paymentId,
              subscriptionId: payment.subscriptionId,
              error: 'Оплата не прошла',
              timestamp: new Date().toISOString(),
            });
          }
        }
      } catch (error) {
        this.logger.error(
          `[SUBSCRIPTION STATUS CHECK] Error checking payment ${paymentId}:`,
          error,
        );
      }
    }, 2000); // Проверяем каждые 2 секунды

    this.paymentCheckIntervals.set(paymentId, interval);
    this.logger.log(
      `[SUBSCRIPTION STATUS CHECK] Interval set for PaymentId: ${paymentId}`,
    );
  }

  // Остановка периодической проверки статуса платежа
  private stopPaymentStatusCheck(paymentId: string) {
    const interval = this.paymentCheckIntervals.get(paymentId);
    if (interval) {
      clearInterval(interval);
      this.paymentCheckIntervals.delete(paymentId);
      this.logger.log(
        `[SUBSCRIPTION STATUS CHECK] Stopped payment status check for PaymentId: ${paymentId}`,
      );
    } else {
      this.logger.log(
        `[SUBSCRIPTION STATUS CHECK] No active interval found for PaymentId: ${paymentId}`,
      );
    }
  }
}
